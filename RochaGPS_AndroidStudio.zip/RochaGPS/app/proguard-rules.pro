# Rocha GPS - no custom ProGuard rules required.
