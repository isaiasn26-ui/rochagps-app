# Rocha GPS - Android Studio

Aplicativo Android da Rocha GPS.

**URL inicial:** https://rochagps.com.br/login

### Recursos
- Splash Screen com o logo enviado
- WebView otimizada
- Geolocalização do site
- Solicitação de localização em primeiro plano
- Upload de arquivos
- Botão voltar
- Pull to Refresh
- Links externos abertos fora do WebView
- HTTPS obrigatório para o domínio

### Como abrir
1. Extraia o ZIP.
2. Abra a pasta `RochaGPS` no Android Studio.
3. Aguarde o Gradle sincronizar.
4. Pressione Run para testar.
5. Para APK: Build > Build App Bundle(s) / APK(s) > Build APK(s).

### Observação
A localização em segundo plano não foi ativada nesta primeira versão. O Android e a Google Play exigem uma justificativa e implementação específica para esse acesso. Se o sistema Rocha GPS realmente precisar rastrear continuamente em segundo plano, isso pode ser acrescentado em uma segunda etapa.
